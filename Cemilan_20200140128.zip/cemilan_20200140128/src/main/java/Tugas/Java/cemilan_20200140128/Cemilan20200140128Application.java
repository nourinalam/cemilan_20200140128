package Tugas.Java.cemilan_20200140128;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cemilan20200140128Application {

	public static void main(String[] args) {
		SpringApplication.run(Cemilan20200140128Application.class, args);
	}

}
