package Tugas.Java.cemilan_20200140128;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cemilan20200140128ApplicationTests {

	@Test
	void contextLoads() {
	}

}
